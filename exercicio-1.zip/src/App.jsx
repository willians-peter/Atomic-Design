import "./App.css";

function App() {
  return <p>Vazio</p>;
}

export default App;
